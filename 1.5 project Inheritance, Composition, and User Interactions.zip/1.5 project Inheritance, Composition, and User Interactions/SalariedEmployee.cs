

namespace EmployeeManagementApp
{
    public class SalariedEmployee : Employee
    {
        public double AnnualSalary { get; set; }

        public SalariedEmployee(int id, string name, double salary, Department dept)
            : base(id, name, dept) // Inheritance
        {
            AnnualSalary = salary;
        }

        public override string ToString()
        {
            return base.ToString() +
                   $"\nType: Salaried\nAnnual Salary: ${AnnualSalary}\n";
        }
    }
}