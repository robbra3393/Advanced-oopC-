﻿

namespace EmployeeManagementApp
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Roberta - Week 1 Inheritance Project");
            Console.WriteLine("Employee Management System\n");


            // Welcome Message
            Console.WriteLine("Welcome");
            Console.WriteLine("This program demonstrates inheritance and composition.\n");


            Department dept1 = new Department("IT", "Norfolk Office");
            Department dept2 = new Department("HR", "Virginia Beach Office");

       
            HourlyEmployee emp1 = new HourlyEmployee(101, "Jorge Simp", 25.00, dept1);

         
            SalariedEmployee emp2 = new SalariedEmployee(102, "Janis thompson", 5000, dept2);

            Console.WriteLine("Employee Records:\n");
           
            Console.WriteLine(emp1);
        
            Console.WriteLine(emp2);
          

            // Exit prompt
            Console.WriteLine("\nPress any key to exit...");
            Console.ReadKey();
        }
    }
}
