
namespace EmployeeManagementApp
{

    public class Employee

    {
        public int ID { get; set; }
        public string Name { get; set; }

        // Composition: Employee HAS-A Department
        public Department Dept { get; set; }

        public Employee(int id, string name, Department dept)
        {
            ID = id;
            Name = name;
            Dept = dept;
        }

        public override string ToString()
        {
            return $"ID: {ID}\nName: {Name}\nDepartment: {Dept}";
        }
    }
}