

namespace EmployeeManagementApp
{
    public class HourlyEmployee : Employee
    {
        public double HourlyRate { get; set; }

        public HourlyEmployee(int id, string name, double rate, Department dept)
            : base(id, name, dept) // Inheritance
        {
            HourlyRate = rate;
        }

        public override string ToString()
        {
            return base.ToString() +
                   $"\nType: Hourly\nHourly Rate: ${HourlyRate}/hr\n";
        }
    }
}