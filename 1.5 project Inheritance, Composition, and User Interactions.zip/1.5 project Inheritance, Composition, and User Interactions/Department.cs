


namespace EmployeeManagementApp
{
    public class Department
    {
        public string DepartmentName { get; set; }
        public string Location { get; set; }

        public Department(string name, string location)
        {
            DepartmentName = name;
            Location = location;
        }

        public override string ToString()
        {
            return $"{DepartmentName} - {Location}";
        }
    }
}